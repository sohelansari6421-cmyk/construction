# from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny, IsAdminUser
from rest_framework.response import Response
from rest_framework import status
from .serializers import ProjectSerializer, ProjectCreateUpdateSerializer
from .models import Project

# Create your views here.


class ProjectListAPIView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):

        projects = Project.objects.all().order_by("-created_at")

        # step 2
        serializer = ProjectSerializer(projects, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class ProjectDetailAPIView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, id):
        try:
            project = Project.objects.get(id=id)
        except Project.DoesNotExist:
            return Response(
                {"message": "Project not found."},
                status=status.HTTP_404_NOT_FOUND,
            )

        serializer = ProjectSerializer(project)
        return Response(serializer.data)


class ProjectCreateAPIView(APIView):
    permission_classes = [IsAdminUser]

    def post(self, request):
        serializer = ProjectCreateUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(
            {
                "message": "Project created successfully.",
                "data": serializer.data,
            },
            status=status.HTTP_201_CREATED,
        )


class ProjectUpdateAPIView(APIView):
    permission_classes = [IsAdminUser]

    def patch(self, request, id):
        try:
            project = Project.objects.get(id=id)
        except Project.DoesNotExist:
            return Response(
                {"message": "Project not found."},
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = ProjectCreateUpdateSerializer(
            instance=project, data=request.data, partial=True
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(
            {
                "message": "Project updated successfully.",
                "data": serializer.data,
            },
            status=status.HTTP_200_OK,
        )


class ProjectDeleteAPIView(APIView):
    permission_classes = [IsAdminUser]

    def delete(self, request, id):
        try:
            project = Project.objects.get(id=id)
        except Project.DoesNotExist:
            return Response(
                {"message": "Project not found."},
                status=status.HTTP_404_NOT_FOUND,
            )

        project.delete()

        return Response(
            {
                "message": "Project deleted successfully.",
            },
            status=status.HTTP_204_NO_CONTENT,
        )
