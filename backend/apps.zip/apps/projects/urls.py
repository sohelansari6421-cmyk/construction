from .views import ProjectListAPIView, ProjectDetailAPIView

from django.urls import path

urlpatterns = [
    path("projects/", ProjectListAPIView.as_view(), name="products"),
    path("projects/<int:id>/", ProjectDetailAPIView.as_view(), name="detail"),
]
